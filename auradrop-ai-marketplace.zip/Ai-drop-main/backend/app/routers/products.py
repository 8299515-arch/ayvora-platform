from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..auth.dependencies import get_current_user, require_admin
from ..database import get_db
from ..models import Category, Product, Review, Supplier, User
from ..schemas import ProductAdminRead, ProductCreate, ProductPublicRead, ReviewCreate, ReviewRead

router = APIRouter(prefix="/api", tags=["commerce"])


# --- Public catalog: NEVER exposes supplier_price/margin ---

@router.get("/products", response_model=list[ProductPublicRead])
def list_products(db: Session = Depends(get_db)):
    return db.query(Product).order_by(Product.ai_score.desc()).all()


@router.get("/products/{product_id}", response_model=ProductPublicRead)
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    return product


# --- Admin-only writes: require_admin guards every mutation ---

@router.post("/products", response_model=ProductAdminRead, dependencies=[Depends(require_admin)])
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    product = Product(**payload.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


@router.put("/products/{product_id}", response_model=ProductAdminRead, dependencies=[Depends(require_admin)])
def update_product(product_id: int, payload: ProductCreate, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    for key, value in payload.model_dump().items():
        setattr(product, key, value)
    db.commit()
    db.refresh(product)
    return product


@router.delete("/products/{product_id}", dependencies=[Depends(require_admin)])
def delete_product(product_id: int, db: Session = Depends(get_db)):
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    db.delete(product)
    db.commit()
    return {"ok": True}


@router.get("/categories")
def categories(db: Session = Depends(get_db)):
    return db.query(Category).all()


@router.get("/suppliers")
def suppliers(db: Session = Depends(get_db)):
    return db.query(Supplier).all()


@router.get("/products/{product_id}/reviews", response_model=list[ReviewRead])
def list_reviews(product_id: int, db: Session = Depends(get_db)):
    return db.query(Review).filter_by(product_id=product_id).order_by(Review.created_at.desc()).all()


@router.post("/products/{product_id}/reviews", response_model=ReviewRead)
def create_review(
    product_id: int,
    payload: ReviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    product = db.get(Product, product_id)
    if not product:
        raise HTTPException(404, "Product not found")
    review = Review(
        product_id=product_id,
        user_id=current_user.id,
        rating=payload.rating,
        comment=payload.comment,
    )
    db.add(review)
    db.commit()
    db.refresh(review)
    return review
