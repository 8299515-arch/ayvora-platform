from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: str = "development"  # "development" | "production"
    database_url: str = "postgresql+psycopg://auradrop:auradrop@localhost:5432/auradrop"
    jwt_secret: str = "change-me-in-production"
    access_token_minutes: int = 30
    refresh_token_days: int = 14
    cors_origins: str = "http://localhost:5173"

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


settings = Settings()

if settings.is_production and settings.jwt_secret == "change-me-in-production":
    raise RuntimeError(
        "JWT_SECRET is still set to the default value while ENVIRONMENT=production. "
        "Set a strong, unique JWT_SECRET before starting the app."
    )
