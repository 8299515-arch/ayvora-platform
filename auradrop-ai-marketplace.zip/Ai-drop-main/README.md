# AuraDrop AI Marketplace

Full-stack AI dropshipping marketplace prototype with React, TypeScript, Tailwind, FastAPI, SQLAlchemy 2.0, PostgreSQL, and Alembic.

## Frontend

```bash
npm install
npm run dev
npm run build
```

## Backend

```bash
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
