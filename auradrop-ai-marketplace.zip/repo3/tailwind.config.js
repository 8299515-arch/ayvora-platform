export default {content:['./index.html','./src/**/*.{ts,tsx}'],theme:{extend:{colors:{obsidian:'#070910',platinum:'#f6f8fb',profit:'#00d084',neon:'#6d5dfc'}}},plugins:[]}
