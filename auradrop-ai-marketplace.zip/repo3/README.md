# AuraDrop AI Marketplace

Full-stack AI dropshipping marketplace: React + TypeScript + Tailwind + Vite frontend,
FastAPI + SQLAlchemy 2.0 + PostgreSQL + Alembic backend.

## Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env             # edit DATABASE_URL / JWT_SECRET / CORS_ORIGINS
alembic upgrade head              # creates all tables

uvicorn app.main:app --reload
```

API is served at `http://localhost:8000`, health check at `/api/health`.

### Auth model

- `POST /api/auth/register`, `/login` — set `access_token` (short-lived) and
  `refresh_token` (long-lived) as HTTPOnly cookies.
- `POST /api/auth/refresh` — reads the `refresh_token` cookie, verifies it, issues a
  new access/refresh pair.
- `GET /api/auth/me` — current user, requires a valid access token.
- Product create/update/delete require `role == "admin"` (set directly in the DB for
  your first admin user, e.g. via `psql` or a one-off script).

### Running the smoke test

`backend/smoke_test.py` exercises the whole API (register/login/admin/products/
orders/reviews/wishlist/refresh) against an in-memory SQLite DB — no Postgres needed:

```bash
cd backend
python smoke_test.py
```

## Frontend

```bash
npm install
npm run dev      # http://localhost:5173
npm run build
```

Configure the API base URL for the frontend in `src/services/apiClient.ts`.

## Docker (production / VPS)

From the repo root:

```bash
cp backend/.env.example .env      # only JWT_SECRET / CORS_ORIGINS are read by compose
docker compose up -d --build
```

This starts Postgres + the backend (migrations run automatically on container start).
Put the frontend behind your own reverse proxy (nginx/caddy) after `npm run build`,
pointing `CORS_ORIGINS` and the frontend's API base URL at your real domain.
