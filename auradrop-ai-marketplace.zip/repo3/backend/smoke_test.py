"""Standalone smoke test: exercises the API end-to-end against an in-memory SQLite DB.
Not part of the shipped app; run manually with `python smoke_test.py` inside the venv.
"""
import sys

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

sys.path.insert(0, ".")
from app.database import Base, get_db  # noqa: E402
from app.main import app  # noqa: E402
from app.models import User  # noqa: E402
from app.auth.security import hash_password  # noqa: E402

engine = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base.metadata.create_all(bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

failures = []


def check(name, cond):
    status = "OK " if cond else "FAIL"
    print(f"[{status}] {name}")
    if not cond:
        failures.append(name)


# health
r = client.get("/api/health")
check("health check", r.status_code == 200)

# register regular user
r = client.post("/api/auth/register", json={"email": "user@test.com", "password": "pass1234"})
check("register user", r.status_code == 200 and "access_token" in r.json())

# duplicate register should fail
r2 = client.post("/api/auth/register", json={"email": "user@test.com", "password": "pass1234"})
check("duplicate register rejected", r2.status_code == 409)

# login
r = client.post("/api/auth/login", json={"email": "user@test.com", "password": "pass1234"})
check("login user", r.status_code == 200)

# wrong password
r = client.post("/api/auth/login", json={"email": "user@test.com", "password": "wrong"})
check("wrong password rejected", r.status_code == 401)

# me (uses cookies set by login TestClient session)
r = client.get("/api/auth/me")
check("me returns user", r.status_code == 200 and r.json()["email"] == "user@test.com")

# non-admin cannot create product
r = client.post("/api/products", json={
    "title": "T", "description": "D", "price": 10, "supplier_price": 5, "margin": 5,
    "category": "cat", "image": "img.png", "ai_score": 50, "stock": 10, "supplier_id": 1,
})
check("non-admin blocked from creating product", r.status_code == 403)

# seed an admin user + supplier directly via DB session
db = TestingSessionLocal()
admin = User(email="admin@test.com", password_hash=hash_password("adminpass"), role="admin")
db.add(admin)
db.commit()
db.close()

admin_client = TestClient(app)
r = admin_client.post("/api/auth/login", json={"email": "admin@test.com", "password": "adminpass"})
check("admin login", r.status_code == 200)

# need a supplier row first (products.supplier_id FK)
from app.models import Supplier  # noqa: E402
db = TestingSessionLocal()
supplier = Supplier(name="Spocket", integration="spocket")
db.add(supplier)
db.commit()
supplier_id = supplier.id
db.close()

r = admin_client.post("/api/products", json={
    "title": "Test Product", "description": "D", "price": 20.0, "supplier_price": 8.0, "margin": 12.0,
    "category": "gadgets", "image": "img.png", "ai_score": 91, "stock": 5, "supplier_id": supplier_id,
})
check("admin creates product", r.status_code == 200)
product_id = r.json()["id"] if r.status_code == 200 else None

r = client.get("/api/products")
check("list products", r.status_code == 200 and len(r.json()) == 1)

if product_id:
    r = client.post("/api/orders", json={"items": [{"product_id": product_id, "quantity": 2}]})
    check("create order", r.status_code == 200 and r.json()["total"] == 40.0)

    r = client.get("/api/orders")
    check("list my orders", r.status_code == 200 and len(r.json()) == 1)

    # over-ordering beyond stock should fail
    r = client.post("/api/orders", json={"items": [{"product_id": product_id, "quantity": 999}]})
    check("overstock order rejected", r.status_code == 409)

    r = client.post(f"/api/products/{product_id}/reviews", json={"rating": 5, "comment": "Great!"})
    check("create review", r.status_code == 200)

    r = client.get(f"/api/products/{product_id}/reviews")
    check("list reviews", r.status_code == 200 and len(r.json()) == 1)

    r = client.post(f"/api/wishlist/{product_id}")
    check("add to wishlist", r.status_code == 200)

    r = client.get("/api/wishlist")
    check("list wishlist", r.status_code == 200 and len(r.json()) == 1)

    r = client.delete(f"/api/wishlist/{product_id}")
    check("remove from wishlist", r.status_code == 200)

# refresh token flow
r = client.post("/api/auth/refresh")
check("refresh token", r.status_code == 200 and "access_token" in r.json())

# logout then me should fail
client.post("/api/auth/logout")
r = client.get("/api/auth/me")
check("me blocked after logout", r.status_code == 401)

print()
if failures:
    print(f"{len(failures)} FAILURES: {failures}")
    sys.exit(1)
else:
    print("ALL CHECKS PASSED")
