def product_score(demand:int, competition:int, margin:float, trend_velocity:int)->dict:
    score=round(demand*.35+(100-competition)*.2+min(margin*2,100)*.3+trend_velocity*.15)
    recommendation='🔥 Hot Product' if score>=85 else '⭐️ Good Opportunity' if score>=65 else '❌ Low Potential'
    return {'ai_score':score,'recommendation':recommendation}
