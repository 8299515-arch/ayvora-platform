def sync_supplier(name:str)->dict:
    if name not in {'Spocket','Printful'}: return {'status':'unsupported','supplier':name}
    return {'status':'synced','supplier':name,'features':['import_products','sync_price','sync_stock','refresh_catalog']}
