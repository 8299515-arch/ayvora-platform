from datetime import datetime

from pydantic import BaseModel, EmailStr


class ProductBase(BaseModel):
    title: str
    description: str
    price: float
    supplier_price: float
    margin: float
    category: str
    image: str
    ai_score: int
    stock: int
    supplier_id: int


class ProductCreate(ProductBase):
    pass


class ProductRead(ProductBase):
    id: int

    class Config:
        from_attributes = True


class UserCreate(BaseModel):
    email: EmailStr
    password: str
    role: str = "customer"


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserRead(BaseModel):
    id: int
    email: EmailStr
    role: str

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class OrderItemCreate(BaseModel):
    product_id: int
    quantity: int


class OrderCreate(BaseModel):
    items: list[OrderItemCreate]


class OrderItemRead(BaseModel):
    product_id: int
    quantity: int
    unit_price: float

    class Config:
        from_attributes = True


class OrderRead(BaseModel):
    id: int
    user_id: int
    total: float
    profit: float
    status: str
    created_at: datetime
    items: list[OrderItemRead] = []

    class Config:
        from_attributes = True


class ReviewCreate(BaseModel):
    rating: int
    comment: str


class ReviewRead(ReviewCreate):
    id: int
    product_id: int
    user_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class WishlistRead(BaseModel):
    id: int
    product_id: int

    class Config:
        from_attributes = True
