from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session

from ..auth.dependencies import get_current_user
from ..auth.security import (
    ACCESS_TOKEN_TYPE,
    REFRESH_TOKEN_TYPE,
    create_token,
    decode_token,
    hash_password,
    verify_password,
)
from ..config import settings
from ..database import get_db
from ..models import User
from ..schemas import LoginRequest, Token, UserCreate, UserRead

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _set_auth_cookies(response: Response, email: str) -> str:
    access_token = create_token(email, ACCESS_TOKEN_TYPE)
    refresh_token = create_token(email, REFRESH_TOKEN_TYPE)
    response.set_cookie(
        "access_token", access_token, httponly=True, secure=settings.is_production, samesite="lax",
        max_age=settings.access_token_minutes * 60,
    )
    response.set_cookie(
        "refresh_token", refresh_token, httponly=True, secure=settings.is_production, samesite="lax",
        max_age=settings.refresh_token_days * 24 * 60 * 60,
    )
    return access_token


@router.post("/register", response_model=Token)
def register(payload: UserCreate, response: Response, db: Session = Depends(get_db)):
    if db.query(User).filter_by(email=payload.email).first():
        raise HTTPException(409, "Email already registered")
    user = User(email=payload.email, password_hash=hash_password(payload.password), role=payload.role)
    db.add(user)
    db.commit()
    access_token = _set_auth_cookies(response, user.email)
    return Token(access_token=access_token)


@router.post("/login", response_model=Token)
def login(payload: LoginRequest, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=payload.email).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid credentials")
    access_token = _set_auth_cookies(response, user.email)
    return Token(access_token=access_token)


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token")
    response.delete_cookie("refresh_token")
    return {"ok": True}


@router.post("/refresh", response_model=Token)
def refresh(request: Request, response: Response, db: Session = Depends(get_db)):
    refresh_token = request.cookies.get("refresh_token")
    if not refresh_token:
        raise HTTPException(401, "Missing refresh token")
    email = decode_token(refresh_token, expected_type=REFRESH_TOKEN_TYPE)
    if not email:
        raise HTTPException(401, "Invalid or expired refresh token")
    user = db.query(User).filter_by(email=email).first()
    if not user:
        raise HTTPException(401, "User not found")
    access_token = _set_auth_cookies(response, user.email)
    return Token(access_token=access_token)


@router.get("/me", response_model=UserRead)
def me(current_user: User = Depends(get_current_user)):
    return current_user
