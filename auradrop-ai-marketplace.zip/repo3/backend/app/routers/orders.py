from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, selectinload

from ..auth.dependencies import get_current_user
from ..database import get_db
from ..models import Order, OrderItem, Product, User
from ..schemas import OrderCreate, OrderRead

router = APIRouter(prefix="/api/orders", tags=["orders"])


@router.post("", response_model=OrderRead)
def create_order(
    payload: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not payload.items:
        raise HTTPException(400, "Order must contain at least one item")

    total = profit = 0.0
    order_items: list[OrderItem] = []
    for item in payload.items:
        product = db.get(Product, item.product_id)
        if not product:
            raise HTTPException(404, f"Product {item.product_id} not found")
        if item.quantity < 1:
            raise HTTPException(400, "Quantity must be at least 1")
        if product.stock < item.quantity:
            raise HTTPException(409, f"Not enough stock for '{product.title}'")
        total += product.price * item.quantity
        profit += product.margin * item.quantity
        product.stock -= item.quantity
        order_items.append(OrderItem(product_id=product.id, quantity=item.quantity, unit_price=product.price))

    order = Order(user_id=current_user.id, total=total, profit=profit, status="sent_to_supplier", items=order_items)
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


@router.get("", response_model=list[OrderRead])
def list_orders(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = db.query(Order).options(selectinload(Order.items)).order_by(Order.created_at.desc())
    if current_user.role != "admin":
        query = query.filter(Order.user_id == current_user.id)
    return query.all()
