from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auth.dependencies import get_current_user
from ..database import get_db
from ..models import Product, User, Wishlist
from ..schemas import WishlistRead

router = APIRouter(prefix="/api/wishlist", tags=["wishlist"])


@router.get("", response_model=list[WishlistRead])
def list_wishlist(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Wishlist).filter_by(user_id=current_user.id).all()


@router.post("/{product_id}", response_model=WishlistRead)
def add_to_wishlist(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not db.get(Product, product_id):
        raise HTTPException(404, "Product not found")
    entry = Wishlist(user_id=current_user.id, product_id=product_id)
    db.add(entry)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Product already in wishlist")
    db.refresh(entry)
    return entry


@router.delete("/{product_id}")
def remove_from_wishlist(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entry = db.query(Wishlist).filter_by(user_id=current_user.id, product_id=product_id).first()
    if not entry:
        raise HTTPException(404, "Not in wishlist")
    db.delete(entry)
    db.commit()
    return {"ok": True}
