export type ThemeName='cyber-dark'|'platinum-light'|'emerald-profit'|'neon-purple-ai';
export interface Product{ id:number; title:string; description:string; price:number; supplierPrice:number; margin:number; category:string; image:string; aiScore:number; rating:number; reviews:number; stock:number; supplier:string; trend:'Hot Product'|'Good Opportunity'|'Low Potential';}
export interface CartItem{product:Product; quantity:number}
export interface AiSeoResult{title:string;description:string;keywords:string[];metaTags:Record<string,string>;schema:Record<string,unknown>}
export interface Order{ id:string; items:CartItem[]; total:number; profit:number; status:string; createdAt:string}
