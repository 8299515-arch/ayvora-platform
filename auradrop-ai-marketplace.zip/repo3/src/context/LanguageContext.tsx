import { createContext, ReactNode, useContext, useState } from 'react';
const LanguageContext=createContext({language:'en',setLanguage:(_l:string)=>{}});
export function LanguageProvider({children}:{children:ReactNode}){const [language,setLanguage]=useState('en'); return <LanguageContext.Provider value={{language,setLanguage}}>{children}</LanguageContext.Provider>}
export const useLanguage=()=>useContext(LanguageContext);
