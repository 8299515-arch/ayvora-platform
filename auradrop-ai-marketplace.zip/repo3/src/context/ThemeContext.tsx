import { createContext, useContext, useMemo, useState, ReactNode } from 'react';
import { ThemeName } from '../types/models';
const themes:Record<ThemeName,string>={'cyber-dark':'from-[#050816] via-[#07111f] to-black text-white','platinum-light':'from-white via-slate-50 to-blue-50 text-slate-950','emerald-profit':'from-[#03140d] via-[#06251a] to-[#00150c] text-emerald-50','neon-purple-ai':'from-[#12051f] via-[#1b0b3a] to-[#060212] text-fuchsia-50'};
const ThemeContext=createContext<{theme:ThemeName;setTheme:(t:ThemeName)=>void;className:string}>({theme:'cyber-dark',setTheme:()=>undefined,className:themes['cyber-dark']});
export function ThemeProvider({children}:{children:ReactNode}){const [theme,setTheme]=useState<ThemeName>('cyber-dark'); const value=useMemo(()=>({theme,setTheme,className:themes[theme]}),[theme]); return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>}
export const useTheme=()=>useContext(ThemeContext);
export const themeOptions=Object.keys(themes) as ThemeName[];
